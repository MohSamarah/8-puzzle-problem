try:
    import time
    import tkinter as tk
    from tkinter import simpledialog
    # 142T35678 125T74368
    goal_state = [' ', '1', '2', '3', '4', '5', '6', '7', '8']
    number_of_expanded_nodes = 0


    def printCurrentState(mat):
        count = 0
        stringt = '-----\n'
        for i in range(9):
            count += 1
            if count % 3 != 0:
                stringt += str(mat[i]) + '|'
                continue
            stringt += str(mat[i]) + '\n'
        stringt += '-----'
        return stringt


    def move_up(mat):
        ind = mat.index(' ')
        if ind < 3:
            return None
        ret_mat = mat[:]
        temp = ret_mat[ind - 3]
        ret_mat[ind - 3] = ' '
        ret_mat[ind] = temp
        return ret_mat


    def move_down(mat):
        ind = mat.index(' ')
        if ind > 5:
            return None
        ret_mat = mat[:]
        temp = ret_mat[ind + 3]
        ret_mat[ind + 3] = ' '
        ret_mat[ind] = temp
        return ret_mat


    def move_left(mat):
        ind = mat.index(' ')
        lis = [0, 3, 6]
        if ind in lis:
            return None
        ret_mat = mat[:]
        temp = mat[ind - 1]
        ret_mat[ind - 1] = ' '
        ret_mat[ind] = temp
        return ret_mat


    def move_right(mat):
        ind = mat.index(' ')
        lis = [2, 5, 8]
        if ind in lis:
            return None
        ret_mat = mat[:]
        temp = ret_mat[ind + 1]
        ret_mat[ind + 1] = ' '
        ret_mat[ind] = temp
        return ret_mat


    def expand_node(node):
        global number_of_expanded_nodes
        list_of_expanded_nodes = [makeNode(move_right(node.state), node, node.cost + 1, 'right'),
                                  makeNode(move_left(node.state), node, node.cost + 2, 'left'),
                                  makeNode(move_up(node.state), node, node.cost + 3, 'up'),
                                  makeNode(move_down(node.state), node, node.cost + 4, 'down')]
        res = []
        for i in range(len(list_of_expanded_nodes)):
            s = list_of_expanded_nodes[i].state
            if s is not None:
                printCurrentState(s)
                res.append(list_of_expanded_nodes[i])
                number_of_expanded_nodes += 1
        return res


    def uniform_cost(start_state, goal_state):
        current = makeNode(start_state, None, 0, None)
        fringe = []
        while current.state != goal_state:
            expanded_nodes = expand_node(current)
            for i in expanded_nodes:
                i.cost += current.cost
                fringe.append(i)
            fringe.sort(key=lambda x: x.cost)

            current = fringe.pop(0)
        cost = 0
        path = []
        while current.parent is not None:
            path.insert(0, current.move)
            if current.move == 'up':
                cost += 3
            elif current.move == 'down':
                cost += 4
            elif current.move == 'right':
                cost += 2
            else:
                cost += 1
            current = current.parent

        return path, cost


    class Node:
        def __init__(self, state, parent, cost, move):
            self.state = state
            self.parent = parent
            self.cost = cost
            self.move = move


    def makeNode(state, parent, cost, move):
        return Node(state, parent, cost, move)


    def app():
        global number_of_expanded_nodes
        root = tk.Tk()
        root.withdraw()
        matrix = tk.simpledialog.askstring(title="Mohammed Alsamarah 128384", prompt="                     enter your "
                                                                                     "starting position to "
                                                                                     "solve \n8-puzzle problem using "
                                                                                     "the Uniform-cost search "
                                                                                     "algorithm", initialvalue=
                                        "142T35678")

        matrix = matrix.replace('T', ' ')
        matrix = list(matrix)
        start_time = time.clock()
        result = uniform_cost(matrix,
                              goal_state)
        visualize_solution = [matrix]
        for i in range(1, len(result[0]) + 1):
            new_mat = visualize_solution[i - 1]
            if result[0][i - 1] == 'up':
                st = move_up(new_mat)
            elif result[0][i - 1] == 'down':
                st = move_down(new_mat)

            elif result[0][i - 1] == 'right':
                st = move_right(new_mat)

            else:
                st = move_left(new_mat)
            visualize_solution.append(st)
        strn = printCurrentState(matrix)

        for i in range(1, len(visualize_solution)):
            if result[0][i - 1] == 'up':
                strn += '\n⇊⇊UP⇊⇊\n' + printCurrentState(visualize_solution[i])
            elif result[0][i - 1] == 'down':
                strn += '\n⇊DOWN⇊\n' + printCurrentState(visualize_solution[i])
            elif result[0][i - 1] == 'right':
                strn += '\n⇊RIGHT⇊\n' + printCurrentState(visualize_solution[i])
            else:
                strn += '\n⇊LEFT⇊\n' + printCurrentState(visualize_solution[i])

        string = 'number of moves is: ' + str(len(result[0])) + '\ntotal cost is     : ' + str(
            result[1]) + '\nsolution is    ' \
                         '   :' + str(
            result[0]) + '\nnumber of expanded nodes: ' + str(number_of_expanded_nodes)
        number_of_expanded_nodes = 0
        root = tk.Tk()
        new_text = tk.Text(root, bg='deepskyblue')

        new_text.insert(tk.INSERT, string + '\ntotal time to find solution:' + str(time.clock()-start_time) + '\n' + strn )
        new_text.pack()
        root.mainloop()


    master = tk.Tk()
    button = tk.Button(master, bg='deepskyblue', height=10, text="click here to start application", command=app)
    button.pack()
    master.mainloop()
    # 142T35678 125T74368


except:  # if you don't have tkinter

    # 142T35678 125T74368
    goal_state = [' ', '1', '2', '3', '4', '5', '6', '7', '8']
    number_of_expanded_nodes = 0


    def printCurrentState(mat):
        count = 0
        stringt = '-----\n'
        for i in range(9):
            count += 1
            if count % 3 != 0:
                stringt += str(mat[i]) + '|'
                continue
            stringt += str(mat[i]) + '\n'
        stringt += '-----'
        return stringt


    def move_up(mat):
        ind = mat.index(' ')
        if ind < 3:
            return None
        ret_mat = mat[:]
        temp = ret_mat[ind - 3]
        ret_mat[ind - 3] = ' '
        ret_mat[ind] = temp
        return ret_mat


    def move_down(mat):
        ind = mat.index(' ')
        if ind > 5:
            return None
        ret_mat = mat[:]
        temp = ret_mat[ind + 3]
        ret_mat[ind + 3] = ' '
        ret_mat[ind] = temp
        return ret_mat


    def move_left(mat):
        ind = mat.index(' ')
        lis = [0, 3, 6]
        if ind in lis:
            return None
        ret_mat = mat[:]
        temp = mat[ind - 1]
        ret_mat[ind - 1] = ' '
        ret_mat[ind] = temp
        return ret_mat


    def move_right(mat):
        ind = mat.index(' ')
        lis = [2, 5, 8]
        if ind in lis:
            return None
        ret_mat = mat[:]
        temp = ret_mat[ind + 1]
        ret_mat[ind + 1] = ' '
        ret_mat[ind] = temp
        return ret_mat


    def expand_node(node):
        global number_of_expanded_nodes
        list_of_expanded_nodes = [makeNode(move_right(node.state), node, node.cost + 1, 'right'),
                                  makeNode(move_left(node.state), node, node.cost + 2, 'left'),
                                  makeNode(move_up(node.state), node, node.cost + 3, 'up'),
                                  makeNode(move_down(node.state), node, node.cost + 4, 'down')]
        res = []
        for i in range(len(list_of_expanded_nodes)):
            s = list_of_expanded_nodes[i].state
            if s is not None:
                printCurrentState(s)
                res.append(list_of_expanded_nodes[i])
                number_of_expanded_nodes += 1
        return res


    def uniform_cost(start_state, goal_state):
        current = makeNode(start_state, None, 0, None)
        fringe = []
        while current.state != goal_state:
            expanded_nodes = expand_node(current)
            for i in expanded_nodes:
                i.cost += current.cost
                fringe.append(i)
            fringe.sort(key=lambda x: x.cost)

            current = fringe.pop(0)
        cost = 0
        path = []
        while current.parent is not None:
            path.insert(0, current.move)
            if current.move == 'up':
                cost += 3
            elif current.move == 'down':
                cost += 4
            elif current.move == 'right':
                cost += 2
            else:
                cost += 1
            current = current.parent

        return path, cost


    class Node:
        def __init__(self, state, parent, cost, move):
            self.state = state
            self.parent = parent
            self.cost = cost
            self.move = move


    def makeNode(state, parent, cost, move):
        return Node(state, parent, cost, move)

    while True:
        matrix = input("enter your starting position: ")
        matrix = matrix.replace('T', ' ')
        matrix = list(matrix)
        result = uniform_cost(matrix,
                              goal_state)
        visualize_solution = [matrix]
        for i in range(1, len(result[0]) + 1):
            new_mat = visualize_solution[i - 1]
            if result[0][i - 1] == 'up':
                st = move_up(new_mat)
            elif result[0][i - 1] == 'down':
                st = move_down(new_mat)

            elif result[0][i - 1] == 'right':
                st = move_right(new_mat)

            else:
                st = move_left(new_mat)
            visualize_solution.append(st)
        strn = printCurrentState(matrix)

        for i in range(1, len(visualize_solution)):
            if result[0][i - 1] == 'up':
                strn += '\n⇊⇊UP⇊⇊\n' + printCurrentState(visualize_solution[i])
            elif result[0][i - 1] == 'down':
                strn += '\n⇊DOWN⇊\n' + printCurrentState(visualize_solution[i])
            elif result[0][i - 1] == 'right':
                strn += '\n⇊RIGHT⇊\n' + printCurrentState(visualize_solution[i])
            else:
                strn += '\n⇊LEFT⇊\n' + printCurrentState(visualize_solution[i])

        string = 'number of moves is: ' + str(len(result[0])) + '\ntotal cost is     : ' + str(
            result[1]) + '\nsolution is    ' \
                         '   :' + str(
            result[0]) + '\nnumber of expanded nodes: ' + str(number_of_expanded_nodes)
        number_of_expanded_nodes = 0
        print(string)
    # 142T35678 125T74368
